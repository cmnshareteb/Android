package com.example.admin.payment_app;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class SecondActivity extends AppCompatActivity {

    private EditText payid;
    private EditText paypasswd;
    private TextView info;
    private Button pay;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        payid = findViewById(R.id.etPaymentID);
        paypasswd = findViewById(R.id.etPayPassword);
        info = findViewById(R.id.tvInfo);
        pay= findViewById(R.id.btnPay);

        info.setText("Fees = "+String.valueOf(MyGlobals.fees));

        pay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {

                validatePayment(payid.getText().toString(),paypasswd.getText().toString());
            }
        });

    }

    private void validatePayment(String pid,String ppasswd)
    {
        if((pid.equals("pkw")) && (ppasswd.equals("pkw")))
        {
            MyGlobals.fees_paid = true;
            Intent intent2 = new Intent(SecondActivity.this,ThridActivity.class);
            startActivity(intent2);
        }
        else
        {
            Toast.makeText(this, "INVALID LOGIN!!", Toast.LENGTH_SHORT).show();
        }
    }
}
