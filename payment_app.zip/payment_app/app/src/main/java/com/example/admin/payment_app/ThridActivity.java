package com.example.admin.payment_app;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class ThridActivity extends AppCompatActivity {


    private TextView msg;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_thrid);

        msg = findViewById(R.id.tvMsg);

        if(MyGlobals.fees_paid == false)
        {
            msg.setText("Fees payment not Successfully!");
        }
        else
        {
            msg.setText("Fees payment successful!!!");
        }
    }
}
