package com.example.admin.payment_app;

public class MyGlobals
{
    public static boolean fees_paid=false;
    public static int fees = 500;

}
